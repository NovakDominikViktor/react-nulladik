import React, { useState } from 'react';
import './App.css';

function App() {
  return (
    <div className="border">
      Dobozok - App
      <BoxComponent hatterSzin="red" kezdetiSzamlalo={0} magassaga={262} szelessege={351} />
      <BoxComponent hatterSzin="blue" kezdetiSzamlalo={1} magassaga={623} szelessege={594}/>
      <BoxComponent hatterSzin="green" kezdetiSzamlalo={7} magassaga={387} szelessege={616}/>
      <BoxComponent hatterSzin="pink" kezdetiSzamlalo={4} magassaga={292} szelessege={336}/>
    </div>
  );
}

function BoxComponent(props) {
  const [szamlaloAllapota, ujSzamlaloAllapotBeallitasa] = useState(props.kezdetiSzamlalo);
  return (
<div
      style={{
        width: props.szelessege,
        height: props.magassaga,
        backgroundColor: props.hatterSzin,
      }}
      className="p-2 m-5 rounded"
      onClick={() => {
        ujSzamlaloAllapotBeallitasa((elozoAllapot) => elozoAllapot + 1);
      }}
    >
      <h1>{szamlaloAllapota}</h1>
    </div>
  );
}

export default App;